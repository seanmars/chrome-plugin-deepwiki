// background.js
chrome.runtime.onInstalled.addListener(() => {
  //
});
